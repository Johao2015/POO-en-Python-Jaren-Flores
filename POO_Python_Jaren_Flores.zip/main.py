# Programa de ejemplo de Programación Orientada a Objetos (POO)
# Autor: Jaren Flores

class Persona:
    def __init__(self, nombre, edad):
        # Encapsulación: atributos protegidos
        self._nombre = nombre
        self._edad = edad

    def describir(self):
        return f"Nombre: {self._nombre}, Edad: {self._edad}"

    def rol(self):
        # Método que será sobrescrito (polimorfismo)
        return "Persona general"


class Estudiante(Persona):
    def __init__(self, nombre, edad, carrera):
        super().__init__(nombre, edad)
        self.carrera = carrera

    # Polimorfismo: sobrescritura de método
    def rol(self):
        return f"Estudiante de la carrera de {self.carrera}"


def main():
    persona1 = Persona("Carlos", 40)
    estudiante1 = Estudiante("Ana", 20, "Ingeniería en Sistemas")

    print(persona1.describir())
    print(persona1.rol())

    print(estudiante1.describir())
    print(estudiante1.rol())


if __name__ == "__main__":
    main()

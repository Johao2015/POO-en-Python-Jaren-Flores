# Aplicación de Conceptos de POO en Python

**Autor:** Jaren Flores  

## Descripción
Este proyecto es un ejemplo sencillo de Programación Orientada a Objetos (POO) en Python.  
Se implementan los conceptos fundamentales solicitados en la tarea académica.

## Conceptos Aplicados
- **Clases y Objetos:** Se define la clase base `Persona` y la clase derivada `Estudiante`.
- **Herencia:** `Estudiante` hereda atributos y métodos de `Persona`.
- **Encapsulación:** Los atributos `_nombre` y `_edad` están protegidos.
- **Polimorfismo:** El método `rol()` es sobrescrito en la clase `Estudiante`.

## Ejecución
1. Abrir el proyecto en PyCharm.
2. Ejecutar el archivo `main.py`.

## Publicación
Este proyecto fue desarrollado en PyCharm y está listo para ser publicado en un repositorio público de GitHub.
